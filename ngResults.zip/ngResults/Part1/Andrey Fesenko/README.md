# Home Work
Desription goes here `display: inline-block`

### How to

```
.truncated {
	direction: rtl;
	white-space: nowrap;
	overflow: hidden;
	text-align: left;
	text-overflow: ellipsis;
}
```

[Moment.js](http://momentjs.com/)

[this](https://i.gyazo.com/f0ac97d27450a7c21467e5943d30195a.png)